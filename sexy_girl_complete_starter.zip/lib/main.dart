import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

void main() => runApp(const OmeShakibApp());

const brand = Color(0xFF7357FF);

class OmeShakibApp extends StatelessWidget {
  const OmeShakibApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sexy Girl',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0B1020),
        colorScheme: ColorScheme.fromSeed(seedColor: brand, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final RTCVideoRenderer _local = RTCVideoRenderer();
  final RTCVideoRenderer _remote = RTCVideoRenderer();
  MediaStream? _stream;
  IO.Socket? _socket;
  RTCPeerConnection? _peer;
  bool _busy = false;
  bool _connected = false;
  String _status = 'Ready to meet someone new';
  String _country = 'Any country';
  final TextEditingController _server = TextEditingController(text: 'http://YOUR_SERVER_IP:3000');

  @override
  void initState() {
    super.initState();
    _initRenderers();
  }

  Future<void> _initRenderers() async {
    await _local.initialize();
    await _remote.initialize();
    if (mounted) setState(() {});
  }

  Future<void> _start() async {
    if (_busy) return;
    setState(() { _busy = true; _status = 'Requesting camera and microphone...'; });
    try {
      final cam = await Permission.camera.request();
      final mic = await Permission.microphone.request();
      if (!cam.isGranted || !mic.isGranted) {
        throw Exception('Camera and microphone permissions are required.');
      }

      _stream ??= await navigator.mediaDevices.getUserMedia({
        'audio': true,
        'video': {'facingMode': 'user', 'width': 640, 'height': 480}
      });
      _local.srcObject = _stream;

      final url = _server.text.trim();
      if (url.contains('YOUR_SERVER_IP')) {
        setState(() {
          _status = 'Camera is ready. Add your signaling server URL to connect.';
          _busy = false;
        });
        return;
      }

      _socket = IO.io(url, <String, dynamic>{
        'transports': ['websocket'],
        'autoConnect': true,
      });
      _socket!.onConnect((_) {
        _socket!.emit('join', {'country': _country});
        if (mounted) setState(() => _status = 'Finding a person...');
      });
      _socket!.on('matched', (data) async {
        await _createPeer(data['initiator'] == true);
      });
      _socket!.on('signal', (data) async {
        final description = data['description'];
        if (description != null) {
          await _peer?.setRemoteDescription(
            RTCSessionDescription(description['sdp'], description['type']),
          );
          if (description['type'] == 'offer') {
            final answer = await _peer!.createAnswer();
            await _peer!.setLocalDescription(answer);
            _socket?.emit('signal', {'description': answer.toMap()});
          }
        }
        final candidate = data['candidate'];
        if (candidate != null) {
          await _peer?.addCandidate(RTCIceCandidate(
            candidate['candidate'], candidate['sdpMid'], candidate['sdpMLineIndex']));
        }
      });
      _socket!.on('partner-left', (_) => _endCall(showMessage: 'The other person left.'));
    } catch (e) {
      setState(() => _status = 'Could not start: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _createPeer(bool initiator) async {
    final config = {
      'iceServers': [
        {'urls': 'stun:stun.l.google.com:19302'}
      ]
    };
    _peer = await createPeerConnection(config);
    for (final track in _stream!.getTracks()) {
      await _peer!.addTrack(track, _stream!);
    }
    _peer!.onTrack = (event) {
      if (event.streams.isNotEmpty) {
        _remote.srcObject = event.streams.first;
        if (mounted) setState(() { _connected = true; _status = 'Connected'; });
      }
    };
    _peer!.onIceCandidate = (candidate) {
      if (candidate.candidate != null) {
        _socket?.emit('signal', {'candidate': candidate.toMap()});
      }
    };
    if (initiator) {
      final offer = await _peer!.createOffer();
      await _peer!.setLocalDescription(offer);
      _socket?.emit('signal', {'description': offer.toMap()});
    }
  }

  Future<void> _endCall({bool showMessage = false}) async {
    await _peer?.close();
    _peer = null;
    _remote.srcObject = null;
    _socket?.disconnect();
    _socket?.dispose();
    _socket = null;
    if (mounted) setState(() {
      _connected = false;
      _busy = false;
      _status = showMessage ? 'The other person left. Tap Next to try again.' : 'Call ended';
    });
  }

  Future<void> _next() async {
    await _endCall();
    await _start();
  }

  @override
  void dispose() {
    _socket?.dispose();
    _peer?.close();
    _stream?.dispose();
    _local.dispose();
    _remote.dispose();
    _server.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SEXY GIRL', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2)),
        centerTitle: true,
        actions: [
          IconButton(
            tooltip: 'Server settings',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => showDialog(context: context, builder: (context) => AlertDialog(
              title: const Text('Connection settings'),
              content: TextField(controller: _server, decoration: const InputDecoration(labelText: 'Signaling server URL')),
              actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Save'))],
            )),
          )
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 10, 18, 12),
              child: Row(children: [
                const Icon(Icons.public, color: brand),
                const SizedBox(width: 10),
                const Text('Match with', style: TextStyle(fontWeight: FontWeight.w600)),
                const Spacer(),
                DropdownButton<String>(
                  value: _country,
                  dropdownColor: const Color(0xFF18213A),
                  items: ['Any country', 'Bangladesh', 'India', 'United States', 'Saudi Arabia']
                      .map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                  onChanged: (v) => setState(() => _country = v ?? 'Any country'),
                )
              ]),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                child: Column(children: [
                  Expanded(child: _videoPanel(_connected ? _remote : null, 'STRANGER', Icons.person_outline)),
                  const SizedBox(height: 10),
                  Expanded(child: _videoPanel(_local, 'YOU', Icons.videocam_outlined)),
                ]),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 22),
              child: Column(children: [
                Text(_status, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
                const SizedBox(height: 14),
                Row(children: [
                  Expanded(child: OutlinedButton.icon(
                    onPressed: _connected || _busy ? () => _endCall() : null,
                    icon: const Icon(Icons.stop_circle_outlined),
                    label: const Text('Stop'),
                    style: OutlinedButton.styleFrom(minimumSize: const Size(0, 52)),
                  )),
                  const SizedBox(width: 10),
                  Expanded(flex: 2, child: FilledButton.icon(
                    onPressed: _busy ? null : (_connected ? _next : _start),
                    icon: Icon(_connected ? Icons.skip_next : Icons.video_call),
                    label: Text(_connected ? 'NEXT' : 'START'),
                    style: FilledButton.styleFrom(backgroundColor: brand, minimumSize: const Size(0, 52)),
                  )),
                ]),
                const SizedBox(height: 8),
                const Text('Be respectful. Never share private information.', style: TextStyle(fontSize: 11, color: Colors.white54)),
              ]),
            ),
          ],
        ),
      ),
    );
  }

  Widget _videoPanel(RTCVideoRenderer? renderer, String label, IconData placeholder) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Container(
        width: double.infinity,
        color: const Color(0xFF18213A),
        child: Stack(fit: StackFit.expand, children: [
          if (renderer != null && renderer.srcObject != null)
            RTCVideoView(renderer, mirror: label == 'YOU', objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover)
          else
            Center(child: Icon(placeholder, size: 64, color: Colors.white24)),
          Positioned(left: 12, top: 12, child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(30)),
            child: Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1)),
          )),
        ]),
      ),
    );
  }
}
