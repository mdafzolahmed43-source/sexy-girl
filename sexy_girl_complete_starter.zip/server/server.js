const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
const waiting = new Map();

app.get('/', (_req, res) => res.send('Ome Shakib signaling server is running'));

io.on('connection', socket => {
  let partnerId = null;
  let roomCountry = 'Any country';

  socket.on('join', ({ country = 'Any country' } = {}) => {
    roomCountry = country;
    const waitingSocket = waiting.get(country) || waiting.get('Any country');
    if (waitingSocket && waitingSocket !== socket.id) {
      waiting.delete(country);
      partnerId = waitingSocket;
      const partner = io.sockets.sockets.get(partnerId);
      if (partner) {
        partner.data.partnerId = socket.id;
        socket.data.partnerId = partnerId;
        partner.emit('matched', { initiator: false });
        socket.emit('matched', { initiator: true });
      } else {
        waiting.set(country, socket.id);
      }
    } else {
      waiting.set(country, socket.id);
    }
  });

  socket.on('signal', payload => {
    const target = socket.data.partnerId;
    if (target) io.to(target).emit('signal', payload);
  });

  socket.on('disconnect', () => {
    if (waiting.get(roomCountry) === socket.id) waiting.delete(roomCountry);
    const target = socket.data.partnerId;
    if (target) {
      io.to(target).emit('partner-left');
      const other = io.sockets.sockets.get(target);
      if (other) delete other.data.partnerId;
    }
  });
});

const port = process.env.PORT || 3000;
server.listen(port, () => console.log(`Signaling server listening on ${port}`));
