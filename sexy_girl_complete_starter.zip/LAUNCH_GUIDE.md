# SEXY GIRL — launch and build guide

This is an early-stage Flutter/WebRTC starter project. It is **not a finished, tested, production-ready app** and it does not contain a compiled APK or signed iOS app.

## What is included
- Flutter UI starter for a random video chat experience
- Camera/microphone permission requests
- WebRTC peer-connection example
- Socket.IO signaling-server example
- Country preference selector
- Android APK build workflow for GitHub Actions

## Build an Android APK using only a phone + GitHub
1. Download and extract this ZIP.
2. Create a GitHub account if you do not already have one.
3. Create a new repository named `sexy-girl`.
4. Upload the extracted project files and folders to the repository (including `.github/workflows/android-apk.yml`).
5. Open the repository's **Actions** tab and enable workflows if GitHub asks.
6. Run **Build Sexy Girl Android APK** using **Run workflow**.
7. When the workflow succeeds, open the run and download the `sexy-girl-android-apk` artifact.
8. Extract the downloaded artifact ZIP to get `app-release.apk`.

The build workflow generates the standard Android/iOS platform folders with Flutter before building Android. You must review the generated Android manifest and iOS Info.plist and add camera/microphone usage descriptions before release.

## iPhone build
An iOS build requires a macOS runner with Xcode. A distributable App Store/TestFlight app also requires Apple signing certificates, provisioning profiles, and an Apple Developer account. The Android workflow above does not create an installable iPhone app.

## Required before real public video chat
The signaling server in `server/server.js` is a demonstration only. Do not expose it publicly as-is. Before launch, implement and test:
- Authentication and verified age gate (18+ if the service is adult-only)
- Strong moderation: report, block, ban, human review and abuse escalation
- TURN relay service; STUN alone is insufficient on many mobile networks
- HTTPS/WSS, authentication tokens, input validation and rate limiting
- Safe random-match queue logic, reconnect handling and concurrency protection
- Privacy policy, terms, data retention/deletion and consent flows
- Child-safety protections and app-store policy compliance
- Server monitoring, logging that avoids unnecessary sensitive data, backups and incident response
- Real-device testing on multiple Android and iPhone models and network types

## Costs and accounts
Flutter and the starter code are free. Public hosting, TURN bandwidth, moderation, domain name, Google Play developer registration and Apple Developer Program membership may incur costs. Do not promise a permanently free production service.

## Important
The name `SEXY GIRL` is only the current display branding. Check trademark availability and app-store naming/content rules before publishing. Do not market the service as a way to contact minors or facilitate sexual exploitation. A random video chat product needs strong safety-by-design controls.
