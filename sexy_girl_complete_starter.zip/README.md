# Sexy Girl — starter project

This is a **starter codebase**, not a finished, production-ready OmeTV clone.

## Included
- Flutter app shell for Android and iOS
- Random video-chat screen UI
- Camera/microphone permission requests
- WebRTC peer connection and Socket.IO signaling example
- Basic country filter and Next/Stop controls

## Requirements
- Flutter SDK (current stable)
- Android Studio for Android builds
- macOS + Xcode for iOS builds
- Node.js for the signaling server

## Run the signaling server
```bash
cd server
npm install
npm start
```
Deploy it to a publicly reachable HTTPS/WSS host for real users. Do not use `localhost` on a phone unless the server is running on that phone.

## Run the Flutter app
```bash
flutter pub get
flutter run
```
Open the settings gear in the app and enter your server URL, for example:
`https://your-signaling-server.example`

## Important before public launch
This starter is not production-ready. It needs, at minimum:
- A TURN server (STUN alone will fail on some networks)
- Secure authentication and age-appropriate access controls
- Reporting, blocking, moderation and abuse response workflows
- Rate limits, spam prevention, privacy policy and terms
- Secure country matching and robust queue/room handling
- Testing on real Android and iOS devices
- App Store / Play Store compliance and developer accounts

The example signaling server is intentionally minimal and should not be exposed to the public as-is. Add authentication, validation, abuse controls, HTTPS, monitoring and robust matching before launch.

## Platform notes
Android permissions are requested at runtime. Review Android manifest permissions and iOS `Info.plist` camera/microphone usage descriptions as required by the plugin versions. iOS builds require macOS and Xcode.
